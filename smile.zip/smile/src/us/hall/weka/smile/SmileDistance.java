package us.hall.weka.smile;

import smile.math.distance.Distance;

public interface SmileDistance {

	public Distance getSmileDistance();
}